import { useState } from "react";

function Nav() {
    const [click, setClick] = useState(false);
    const handleclick = () => setClick(!click);
    return (
       <div className='nav'>
        <p onClick={handleclick}>☰</p>
        {
           click &&  (
            <div className="navlinks">
            <a href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#services">Services</a>
            <a href="#contact">Contact</a>
            </div>
           )
        }
       </div>
    )
}
export default Nav;