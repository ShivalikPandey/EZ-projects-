import { useActionState } from "react";
import { useState } from "react";

// form handler send request to add new user data to server
function Userform() {
  const [color, setColor] = useState("");
  const [rresult, setRresult] = useState(null);
  const handleformSubmit = async (previousData, formdata) => {
    let name = formdata.get("name");
    let email = formdata.get("email");
    let phone = formdata.get("number");
    let message = formdata.get("message");

    // name validating
    if(name=="" || (phone<1 && phone>9999999999)){
      setColor('red')
      return "Name and number is required";
    }
    

    try {
      const response = await fetch("https://vernanbackend.ezlab.in/api/contact-us/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name, email, phone, message }),
      });
      // checking response status
      if (!response.ok) {
        setColor("darkred");
        throw new Error("Server error");
        // return after throw is unreachable, so removed
      }

      const result = await response.json();
      setRresult(result);
      setColor("green");
      return "Submitted successfully";
    } catch (err) {
      return "Fill all the fields correctly";
    }
  };

  // useActionState
  const [data, action, pending] = useActionState(handleformSubmit, undefined);

  return (
    <>
         
      <form className="common form" action={action}>
        <input type="text" name="name" placeholder="Enter your name" className="fields"/>
        <input type="email" name="email" placeholder="Enter your email" className="fields"/>
        <input type="number" name="number" placeholder="Enter your number" className="fields"/>
        <textarea name="message" placeholder="Enter your message" className="fields"/>
        <button type="submit" className="fields">{pending ? "Submitting..." : "Submit"}</button>
              {data && <p style={{backgroundColor:'white',color:color}}>{data}</p>}
               {/* displaying result from server */}
               {
        rresult && (<div className="result">
        <p className="colorset">{rresult.data.id}</p>
        <p className="colorset">{rresult.data.name}</p>
        <p className="colorset">{rresult.data.phone}</p>
        <p className="colorset">{rresult.data.message}</p>
        <p className="colorset">{rresult.data.email}</p>
      </div>)
      }
      </form>
    </>
  );
}

export default Userform;
