import Nav from './Nav.jsx'
import Userform from './form.jsx'
import './form.css'
import './Nav.css'
function App() {
  return (
    <div className='common'>
     <Nav />
<p style={{ 
  textAlign: 'center', 
  color: 'yellow', 
  fontSize: (window.innerWidth >= 2500 && window.innerWidth <= 2800 && window.innerHeight >= 2000 && window.innerHeight <= 2100) ? '6vw' : '40px', 
  marginTop:  (window.innerWidth >= 1400 && window.innerWidth <= 2800 && window.innerHeight >= 800 && window.innerHeight <= 2100) ? '12vh' : '60px',  
}}>
  New User
</p>

     <Userform />
    </div>
  );
}

export default App;